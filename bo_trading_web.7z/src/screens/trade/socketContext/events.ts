import {EVENTS, ROOM} from 'constants/socketConfig';
import {Socket} from 'socket.io-client';
import {ContextType} from './context';

export const socketEvents = ({setValue, socket}) => {
  if (!socket) return;

  socket.on('connect', () => {
    socket.emit(ROOM.ETHUSDT);
    socket.emit(ROOM.INDICATOR_ETHUSDT);
  });

  socket.on(EVENTS.BLOCKS_ETHUSDT, (result: any) => {
    // thêm object vào mảng block cuối cùng để front-end runtime data
    let blocks: any = [...result];
    blocks.push(blocks[blocks.length - 1]);
    console.log(blocks, 'cryptoBlocks');
    setValue((state: ContextType) => ({...state, blocks}));
  });

  socket.on(EVENTS.ETHUSDT_REALTIME, (result: any) => {
    console.log(result, 'data');
    const data = result.candlestick;
    const timeTick = result.timeTick % 30;
    setValue((state: ContextType) => ({...state, data, timeTick}));
  });

  socket.on(EVENTS.INDICATOR_ETHUSDT, function (data) {
    console.log(data, 'data');
  });
};

export const socketDisconnect = (socket: Socket | null) => {
  if (!socket) return;
  socket.off(EVENTS.BLOCKS_ETHUSDT);
  socket.off(EVENTS.ETHUSDT_REALTIME);
  socket.off(EVENTS.INDICATOR_ETHUSDT);
  socket.disconnect();
};
