export type IProps = {
  height: number;
};
