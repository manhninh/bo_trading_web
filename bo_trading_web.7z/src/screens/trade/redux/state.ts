export type TradeState = {
  timeTick: number;
};
