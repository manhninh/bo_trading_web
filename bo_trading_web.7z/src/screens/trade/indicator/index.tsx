import React, {useState} from 'react';
import ReactSpeedometer, {CustomSegmentLabelPosition, Transition} from 'react-d3-speedometer';
import './styled.css';

const IndicatorComponent = () => {
  const [state, setState] = useState({
    oscillatorsBuy: 0,
    oscillatorsNeutral: 0,
    oscillatorsSell: 0,
    maBuy: 0,
    maNeutral: 0,
    maSell: 0,
    macdBuy: 0,
    macdNeutral: 0,
    macdSell: 0,
    totalBuy: 0,
    totalNeutral: 0,
    totalSell: 0,
    indicator_type: 0,
    indicator: 0,
  });

  // useEffect(() => {
  //   configWs();
  // }, [props.socket]);

  // const configWs = () => {
  //   if (props.socket) {
  //     props.socket.on(EVENTS.INDICATOR_ETHUSDT, function (data) {
  //       console.log(data, 'data');
  //     });
  //   }
  // };

  return (
    <div className="row">
      <div className="col-5 px-0">
        <div className="public-user-block py-2" style={{borderBottom: '1px solid #34373d'}}>
          <div className="row">
            <div className="col-5 px-0">
              <div className="order text-light">Indicator</div>
            </div>
            <div className="col-7 px-0">
              <div className="details d-flex">
                <div className="item text-success">
                  <i className="fas fa-caret-up text-success" />
                  <strong>Buy</strong>
                </div>
                <div className="item text-warning">
                  <i className="fab fa-gg text-warning" />
                  <strong>Neutral</strong>
                </div>
                <div className="item text-danger">
                  <i className="fas fa-caret-down text-danger" />
                  <strong>Sell</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="public-user-block py-2">
          <div className="row">
            <div className="col-5 px-0">
              <div className="order text-info">Oscillators</div>
            </div>
            <div className="col-7 px-0">
              <div className="details d-flex">
                <div className="item">
                  <strong>{state.oscillatorsBuy}</strong>
                </div>
                <div className="item">
                  <strong>{state.oscillatorsNeutral}</strong>
                </div>
                <div className="item">
                  <strong>{state.oscillatorsSell}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="public-user-block py-2">
          <div className="row">
            <div className="col-5 px-0">
              <div className="order text-info">Moving Averages</div>
            </div>
            <div className="col-7 px-0">
              <div className="details d-flex">
                <div className="item">
                  <strong>{state.maBuy}</strong>
                </div>
                <div className="item">
                  <strong>{state.maNeutral}</strong>
                </div>
                <div className="item">
                  <strong>{state.maSell}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="public-user-block py-2">
          <div className="row">
            <div className="col-5 px-0">
              <div className="order text-info">MACD Histogram</div>
            </div>
            <div className="col-7 px-0">
              <div className="details d-flex">
                <div className="item">
                  <strong>{state.macdBuy}</strong>
                </div>
                <div className="item">
                  <strong>{state.macdNeutral}</strong>
                </div>
                <div className="item">
                  <strong>{state.macdSell}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="public-user-block" style={{borderTop: '1px solid #34373d'}}>
          <div className="row">
            <div className="col-7 offset-5 px-0">
              <div className="details d-flex">
                <div className="item text-success">
                  <strong>{state.totalBuy}</strong>
                </div>
                <div className="item text-warning">
                  <strong>{state.totalNeutral}</strong>
                </div>
                <div className="item text-danger">
                  <strong>{state.totalSell}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="col-4 px-0">
        <ReactSpeedometer
          height={189}
          segments={3}
          ringWidth={47}
          needleHeightRatio={0.7}
          segmentColors={['#28a745', '#ffc107', '#F04B4B']}
          currentValueText="Indicator"
          customSegmentLabels={[
            {
              text: 'BUY',
              position: CustomSegmentLabelPosition.Inside,
              color: '#FFFFFF',
            },
            {
              text: 'Neutral',
              position: CustomSegmentLabelPosition.Inside,
              color: '#FFFFFF',
            },
            {
              text: 'SELL',
              position: CustomSegmentLabelPosition.Inside,
              color: '#FFFFFF',
            },
          ]}
          needleTransitionDuration={3333}
          needleTransition={Transition.easeElastic}
          needleColor="#16CEB9"
          textColor="#FFFFFF"
          value={state.indicator_type}
          customSegmentStops={[0, 380, 620, 1000]}
        />
      </div>
      <div className="col-3 px-0">
        <div className="py-2 text-danger text-left" style={{marginTop: '3rem'}}>
          <div className="title text-center" style={{display: 'inline-block', verticalAlign: 'middle'}}>
            <h2>Signal Sell</h2>
            <h2>{state.indicator}%</h2>
          </div>
          <i
            className="fas fa-caret-down text-danger"
            style={{fontSize: 50, marginLeft: '1.5rem', display: 'inline-block', verticalAlign: 'middle'}}
          />
        </div>
      </div>
    </div>
  );
};

export default React.memo(IndicatorComponent);
