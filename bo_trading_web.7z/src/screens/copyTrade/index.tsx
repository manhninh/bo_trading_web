import React from 'react';

const CopyTradeComponent = () => {
  return <div>CopyTrade</div>;
};

export default React.memo(CopyTradeComponent);
