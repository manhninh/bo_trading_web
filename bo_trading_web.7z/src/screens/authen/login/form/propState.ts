export interface IState {
  username: string;
  password: string;
}