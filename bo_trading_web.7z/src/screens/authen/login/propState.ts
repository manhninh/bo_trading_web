export type Props = {
  fnAfterLogin?: () => void;
};
