import React from 'react';

const ForgotPasswordComponent = () => {
  return <div>ForgotPassword</div>;
};

export default React.memo(ForgotPasswordComponent);
