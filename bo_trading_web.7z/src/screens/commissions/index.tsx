import React from 'react';

const CommissionComponent = () => {
  return <div>Commission</div>;
};

export default React.memo(CommissionComponent);
