export type Props = {
  children: JSX.Element | JSX.Element[];
};
