export type CommonState = {
  isLoading: boolean;
}