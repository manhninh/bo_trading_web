export type Props = {
  noBackground?: boolean;
};

export type State = {
  isOpenSignin: boolean;
  isOpenSignup: boolean;
  isAuthen: boolean;
};