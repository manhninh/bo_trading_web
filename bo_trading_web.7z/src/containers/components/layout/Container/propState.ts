export type Props = {
  children: JSX.Element;
  headerTitle?: string;
  backgroundSvg?: JSX.Element;
};
