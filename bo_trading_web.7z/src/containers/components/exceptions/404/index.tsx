import React from 'react';

const NotFoundComponent = () => {
  return <div>NotFound</div>;
};

export default React.memo(NotFoundComponent);
