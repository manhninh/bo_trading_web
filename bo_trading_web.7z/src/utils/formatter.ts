const formatter2 = new Intl.NumberFormat('en-US', {maximumFractionDigits: 2});

export {formatter2};
