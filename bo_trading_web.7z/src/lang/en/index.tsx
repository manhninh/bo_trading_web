import common from './common.json';

const en = {
  common,
};

export default en;
