import common from './common.json';

const vi = {
  common,
};

export default vi;
